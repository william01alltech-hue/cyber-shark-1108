import numpy as np
from PIL import Image

def build_irene_logo(lowercase=True):
    # Canvas size in native pixel units
    # Letter height: 9 pixels (y = 2 to 10)
    # Total grid height: 20 pixels
    # Total grid width: 55 pixels
    
    W, H = 60, 24
    grid = np.zeros((H, W), dtype=int)
    # 0 = empty
    # 1 = letter fill
    # 2 = dot of i
    
    if lowercase:
        # Letters: i, r, e, n, e
        # 'i':
        # x: 4..5 (width 2)
        # dot at y=3..4, x=4..5
        # stem at y=6..12, x=4..5
        grid[3:5, 4:6] = 2 # dot
        grid[6:13, 4:6] = 1 # stem
        
        # 'r':
        # x: 9..14
        # stem at x=9..10, y=6..13
        # arch at y=6..7, x=11..14; arm at y=8, x=13..14
        grid[6:13, 9:11] = 1
        grid[6:8, 11:14] = 1
        grid[7:9, 13:15] = 1
        
        # 'e':
        # x: 17..22
        # top bar: y=6..7, x=17..22
        # left stem: y=7..12, x=17..18
        # mid bar: y=9..10, x=18..22
        # bottom bar: y=12..13, x=17..22
        # right cap of bottom bar: y=11, x=22
        grid[6:8, 17:23] = 1
        grid[7:13, 17:19] = 1
        grid[9:11, 18:23] = 1
        grid[12:14, 17:23] = 1
        grid[11:12, 22:23] = 1
        
        # 'n':
        # x: 26..32
        # left stem: y=6..13, x=26..27
        # top arch: y=6..8, x=28..31
        # right stem: y=7..13, x=31..32
        grid[6:13, 26:28] = 1
        grid[6:8, 28:32] = 1
        grid[8:13, 31:33] = 1
        
        # 'e' (second e):
        # x: 36..41
        grid[6:8, 36:42] = 1
        grid[7:13, 36:38] = 1
        grid[9:11, 37:42] = 1
        grid[12:14, 36:42] = 1
        grid[11:12, 41:42] = 1

    return grid

g = build_irene_logo(True)
for row in g:
    print(''.join(' #'[val > 0] for val in row))
