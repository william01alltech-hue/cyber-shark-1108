import http.server
import socketserver
import os
import subprocess
import json

PORT = 8080
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")

class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def do_POST(self):
        if self.path.startswith("/save-audio"):
            try:
                import urllib.parse
                parsed = urllib.parse.urlparse(self.path)
                params = urllib.parse.parse_qs(parsed.query)
                voice_id = params.get("id", params.get("voice", ["hello"]))[0]

                content_length = int(self.headers.get("Content-Length", 0))
                audio_bytes = self.rfile.read(content_length)

                raw_filename = f"shark_{voice_id}_raw.webm"
                wav_filename = f"shark_{voice_id}.wav"
                mp3_filename = f"shark_{voice_id}.mp3"
                author_wav_filename = f"author_voice_{voice_id}.wav"

                raw_path = os.path.join(ASSETS_DIR, raw_filename)
                wav_path = os.path.join(ASSETS_DIR, wav_filename)
                mp3_path = os.path.join(ASSETS_DIR, mp3_filename)
                author_wav_path = os.path.join(ASSETS_DIR, author_wav_filename)

                os.makedirs(ASSETS_DIR, exist_ok=True)
                with open(raw_path, "wb") as f:
                    f.write(audio_bytes)

                # 使用 ffmpeg 轉檔為高品質 WAV 與 MP3，並自動歸檔作者原聲版
                converted = False
                try:
                    subprocess.run(
                        ["ffmpeg", "-y", "-i", raw_path, "-ac", "1", "-ar", "44100", wav_path],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        check=True
                    )
                    subprocess.run(
                        ["ffmpeg", "-y", "-i", wav_path, mp3_path],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        check=True
                    )
                    subprocess.run(
                        ["cp", wav_path, author_wav_path],
                        check=True
                    )
                    converted = True
                except Exception as e:
                    print("FFmpeg conversion error:", e)

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                response = {
                    "status": "ok",
                    "voice_id": voice_id,
                    "file_saved": f"assets/{wav_filename}" if converted else f"assets/{raw_filename}"
                }
                self.wfile.write(json.dumps(response).encode("utf-8"))
                return
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"status": "error", "message": str(e)}).encode("utf-8"))
                return

        super().do_POST()

if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), CustomHandler) as httpd:
        print(f"Serving HTTP on port {PORT} (http://localhost:{PORT}/) ...")
        httpd.serve_forever()

