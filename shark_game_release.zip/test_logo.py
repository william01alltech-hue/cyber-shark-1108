import numpy as np
from PIL import Image

# Colors from warma reference
# Yellow: #FDE896, #FCD366
# Coral: #EE7263, #E85B4B
# White: #FFFFFF
# Shadow: #D2A89F, #C3988E
# Background: Transparent / White

COLOR_YELLOW_LIGHT = (255, 240, 165)
COLOR_YELLOW = (252, 215, 105)
COLOR_CORAL = (238, 114, 99)
COLOR_CORAL_DARK = (215, 88, 74)
COLOR_WHITE = (255, 255, 255)
COLOR_SHADOW = (205, 168, 160, 255)

print("Setup test")
