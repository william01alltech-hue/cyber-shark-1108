import numpy as np
from PIL import Image

def build_pixel_art_logo(text="irene", scale=7):
    # Palette closely matched from warma_ref.png:
    C_YELLOW_LIGHT = (255, 246, 206, 255) # #FFF6CE top highlight
    C_YELLOW_MAIN  = (252, 219, 107, 255) # #FCDB6B warm pastel yellow
    C_YELLOW_BORDER= (242, 198,  82, 255) # #F2C652
    
    C_CORAL_LIGHT  = (250, 160, 146, 255) # #FAA092 coral transition
    C_CORAL_MAIN   = (238, 114,  98, 255) # #EE7262 primary strawberry coral
    C_CORAL_DARK   = (214,  84,  68, 255) # #D65444 bottom 3D base
    
    C_WHITE        = (255, 255, 255, 255)
    C_SHADOW_MAIN  = (205, 168, 160, 255) # #CDA8A0 warm dusty shadow
    
    H, W = 29, 68
    body_mask = np.zeros((H, W), dtype=bool)
    
    if text == "irene":
        # 'i' (x: 8..11)
        # Dot: 2x2 at y=6..7, x=9..10
        body_mask[6:8, 9:11] = True
        # Stem: 2x7 at y=10..16, x=9..10
        body_mask[10:17, 9:11] = True
        
        # 'r' (x: 14..20)
        # Left stem: 2x7 at y=10..16, x=14..15
        body_mask[10:17, 14:16] = True
        # Top arch: y=10..11, x=16..18
        body_mask[10:12, 16:19] = True
        # Right hook: y=11..13, x=18..20
        body_mask[11:14, 18:20] = True
        
        # 'e' (x: 23..30)
        # Left stem: y=10..16, x=23..24
        body_mask[10:17, 23:25] = True
        # Top bar: y=10..11, x=25..28
        body_mask[10:12, 25:29] = True
        # Top-right eye wall: y=11..12, x=28..29
        body_mask[11:13, 28:30] = True
        # Middle crossbar: y=12..13, x=25..28
        body_mask[12:14, 25:29] = True
        # Bottom bar: y=15..16, x=25..29
        body_mask[15:17, 25:30] = True
        # Bottom-right upward lip: y=14..15, x=28..29
        body_mask[14:16, 28:30] = True
        
        # 'n' (x: 33..40)
        # Left stem: y=10..16, x=33..34
        body_mask[10:17, 33:35] = True
        # Top arch: y=10..11, x=35..38
        body_mask[10:12, 35:39] = True
        # Right stem: y=11..16, x=38..39
        body_mask[11:17, 38:40] = True
        
        # second 'e' (x: 43..50)
        body_mask[10:17, 43:45] = True
        body_mask[10:12, 45:49] = True
        body_mask[11:13, 48:50] = True
        body_mask[12:14, 45:49] = True
        body_mask[15:17, 45:50] = True
        body_mask[14:16, 48:50] = True

    elif text == "Irene":
        # 'I' capital (x: 6..13)
        # Top serif: y=6..7, x=6..12
        body_mask[6:8, 6:13] = True
        # Center stem: y=8..14, x=8..10
        body_mask[8:15, 8:11] = True
        # Bottom serif: y=15..16, x=6..12
        body_mask[15:17, 6:13] = True
        
        # 'r' (x: 16..22)
        body_mask[10:17, 16:18] = True
        body_mask[10:12, 18:21] = True
        body_mask[11:14, 20:22] = True
        
        # 'e' (x: 25..32)
        body_mask[10:17, 25:27] = True
        body_mask[10:12, 27:31] = True
        body_mask[11:13, 30:32] = True
        body_mask[12:14, 27:31] = True
        body_mask[15:17, 27:32] = True
        body_mask[14:16, 30:32] = True
        
        # 'n' (x: 35..42)
        body_mask[10:17, 35:37] = True
        body_mask[10:12, 37:40] = True
        body_mask[11:17, 40:42] = True
        
        # second 'e' (x: 45..52)
        body_mask[10:17, 45:47] = True
        body_mask[10:12, 47:51] = True
        body_mask[11:13, 50:52] = True
        body_mask[12:14, 47:51] = True
        body_mask[15:17, 47:52] = True
        body_mask[14:16, 50:52] = True

    # 3D extrusion under the letters (coral block bottom)
    extrude_mask = np.zeros_like(body_mask)
    for y in range(H - 1):
        extrude_mask[y + 1] = body_mask[y] & ~body_mask[y + 1]
    # Only extrude bottom edges (row >= 15)
    extrude_mask &= (np.arange(H)[:, None] >= 15)

    combined = body_mask | extrude_mask

    # 1-pixel white outline
    outline_mask = np.zeros_like(body_mask)
    for dy in [-1, 0, 1]:
        for dx in [-1, 0, 1]:
            if dx == 0 and dy == 0:
                continue
            shifted = np.roll(np.roll(combined, dy, axis=0), dx, axis=1)
            outline_mask |= shifted
    outline_mask &= ~combined

    # Drop shadow: shift combined + outline down by 1-2 and right by 1
    full_shape = combined | outline_mask
    shadow_mask = np.zeros_like(body_mask)
    for dy in [1, 2]:
        for dx in [0, 1]:
            shifted = np.roll(np.roll(full_shape, dy, axis=0), dx, axis=1)
            shadow_mask |= shifted
    shadow_mask &= ~full_shape

    # Canvas
    canvas = np.zeros((H, W, 4), dtype=np.uint8)

    # 1. Fill shadow
    canvas[shadow_mask] = C_SHADOW_MAIN

    # 2. Fill white outline
    canvas[outline_mask] = C_WHITE

    # 3. Fill 3D extrusion
    canvas[extrude_mask] = C_CORAL_DARK

    # 4. Fill letter body
    # Yellow top (y <= 11)
    # Transition line (y == 12)
    # Coral bottom (y >= 13)
    for y in range(H):
        for x in range(W):
            if body_mask[y, x]:
                if y <= 7:
                    canvas[y, x] = C_YELLOW_LIGHT
                elif y <= 11:
                    canvas[y, x] = C_YELLOW_MAIN
                elif y == 12:
                    canvas[y, x] = C_CORAL_LIGHT
                else:
                    canvas[y, x] = C_CORAL_MAIN

    # 5. Sparkles (4-pointed pixel stars)
    sparkles = [
        # (center_y, center_x, color_type)
        (7, 3, "yellow"),
        (21, 5, "yellow"),
        (6, 58, "coral"),
        (19, 61, "coral"),
    ]
    for sy, sx, stype in sparkles:
        c_main = C_YELLOW_MAIN if stype == "yellow" else C_CORAL_MAIN
        c_light = C_YELLOW_LIGHT if stype == "yellow" else C_CORAL_LIGHT
        
        pts = [(sy, sx), (sy-1, sx), (sy+1, sx), (sy, sx-1), (sy, sx+1)]
        # Add white outline around sparkles
        for py, px in pts:
            for dy in [-1, 0, 1]:
                for dx in [-1, 0, 1]:
                    ny, nx = py + dy, px + dx
                    if 0 <= ny < H and 0 <= nx < W and canvas[ny, nx, 3] == 0:
                        canvas[ny, nx] = C_WHITE
        # Fill sparkle points
        for py, px in pts:
            if 0 <= py < H and 0 <= px < W:
                canvas[py, px] = c_light if (py, px) == (sy, sx) else c_main

    im = Image.fromarray(canvas, mode="RGBA")
    im_scaled = im.resize((W * scale, H * scale), Image.Resampling.NEAREST)
    return im, im_scaled

for name in ["irene", "Irene"]:
    _, im_big = build_pixel_art_logo(name, scale=7)
    im_big.save(f"assets/{name}_logo.png")
    
    # White background version
    bg_white = Image.new("RGBA", im_big.size, (255, 255, 255, 255))
    bg_white.paste(im_big, (0, 0), im_big)
    bg_white.save(f"assets/{name}_logo_white.png")
    print(f"Generated assets/{name}_logo.png and white background version")

