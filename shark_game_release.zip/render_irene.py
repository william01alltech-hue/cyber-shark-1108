import numpy as np
from PIL import Image

def create_irene_bitmap(capital=False):
    # Native resolution: ~64 x 26
    # Let's map pixels
    H, W = 28, 68
    grid = np.zeros((H, W), dtype=int)
    
    # Let's place letters starting around x=10, y=7
    # Letters height = 10 (y=7 to 16)
    
    if not capital:
        # 'i'
        # dot at y=4..5, x=10..11
        grid[4:6, 10:12] = 1
        # stem at y=8..16, x=10..12
        grid[8:17, 10:12] = 1
        
        # 'r'
        # stem at x=15..16, y=8..16
        grid[8:17, 15:17] = 1
        # top curve
        grid[8:10, 17:20] = 1
        grid[9:11, 20:22] = 1
        
        # 'e'
        # left stem
        grid[8:17, 24:26] = 1
        # top bar
        grid[8:10, 26:30] = 1
        # mid bar
        grid[11:13, 26:30] = 1
        # right top closure
        grid[9:12, 29:31] = 1
        # bottom bar
        grid[15:17, 26:31] = 1
        # bottom right lip
        grid[14:16, 30:31] = 1
        
        # 'n'
        # left stem
        grid[8:17, 34:36] = 1
        # top arch
        grid[8:10, 36:39] = 1
        # right stem
        grid[9:17, 39:41] = 1
        
        # second 'e'
        grid[8:17, 44:46] = 1
        grid[8:10, 46:50] = 1
        grid[11:13, 46:50] = 1
        grid[9:12, 49:51] = 1
        grid[15:17, 46:51] = 1
        grid[14:16, 50:51] = 1
    else:
        # 'I' capital
        # top bar: y=5..7, x=8..14
        grid[5:7, 8:14] = 1
        # center stem: y=7..15, x=10..12
        grid[7:15, 10:12] = 1
        # bottom bar: y=15..17, x=8..14
        grid[15:17, 8:14] = 1
        
        # 'r'
        grid[8:17, 16:18] = 1
        grid[8:10, 18:21] = 1
        grid[9:11, 21:23] = 1
        
        # 'e'
        grid[8:17, 25:27] = 1
        grid[8:10, 27:31] = 1
        grid[11:13, 27:31] = 1
        grid[9:12, 30:32] = 1
        grid[15:17, 27:32] = 1
        grid[14:16, 31:32] = 1
        
        # 'n'
        grid[8:17, 35:37] = 1
        grid[8:10, 37:40] = 1
        grid[9:17, 40:42] = 1
        
        # second 'e'
        grid[8:17, 45:47] = 1
        grid[8:10, 47:51] = 1
        grid[11:13, 47:51] = 1
        grid[9:12, 50:52] = 1
        grid[15:17, 47:52] = 1
        grid[14:16, 51:52] = 1

    return grid

g = create_irene_bitmap(False)
print("Bitmap created")
