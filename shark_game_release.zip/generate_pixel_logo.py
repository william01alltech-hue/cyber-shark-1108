import numpy as np
from PIL import Image

# Let's inspect native grid dimensions:
# In warma, each letter is approximately 6-8 pixels wide and 8-10 pixels tall.
# Let's check the exact letter widths:
# 'r': width 6, height 8
# 'm': width 10, height 8
# 'a': width 7, height 8
# 'w': width 10, height 8
#
# So for 'irene':
# 'i': width 3 or 4, height 8 (or with dot, height 9)
# 'r': width 6, height 8
# 'e': width 7, height 8
# 'n': width 7, height 8
# 'e': width 7, height 8

print("Ready to design glyphs")
